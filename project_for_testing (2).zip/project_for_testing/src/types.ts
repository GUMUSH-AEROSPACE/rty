export interface VesselData {
  mmsi: string;
  timestamp: string;
  latitude: number;
  longitude: number;
  speed: number;
  heading: number;
  vesselName?: string;
  vesselType?: string;
  status?: string;
  accuracy?: number;
  turn?: number;
}

export interface FileUploaderProps {
  onDataLoaded: (data: VesselData[]) => void;
}
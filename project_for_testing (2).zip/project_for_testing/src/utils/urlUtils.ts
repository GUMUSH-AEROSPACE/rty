export function createMarineTrafficUrl(mmsi: string): string {
  return `https://www.marinetraffic.com/tr/ais/details/ships/mmsi:${mmsi}`;
}

export function createVesselUrl(vessel: {
  mmsi: string;
  latitude: number;
  longitude: number;
}): string {
  const params = new URLSearchParams({
    mmsi: vessel.mmsi,
    lat: vessel.latitude.toString(),
    lon: vessel.longitude.toString(),
  });
  
  return `${window.location.origin}${window.location.pathname}?${params.toString()}`;
}
import { useMap } from 'react-leaflet';
import { useEffect, useState } from 'react';
import { VesselData } from '../types';

interface ZoomLevelProps {
  selectedVessel?: VesselData | null;
}

export default function ZoomLevel({ selectedVessel }: ZoomLevelProps) {
  const map = useMap();
  const [zoomLevel, setZoomLevel] = useState(map.getZoom());

  useEffect(() => {
    const updateZoom = () => {
      setZoomLevel(map.getZoom());
    };

    map.on('zoomend', updateZoom);

    return () => {
      map.off('zoomend', updateZoom);
    };
  }, [map]);

  return (
    <div className="absolute bottom-4 left-4 z-[1000] bg-white px-4 py-2 rounded-md shadow-md space-y-1">
      <div className="text-sm font-medium">Zoom: {zoomLevel}</div>
      {selectedVessel && (
        <div className="text-sm">
          <div>Lat: {selectedVessel.latitude.toFixed(4)}°</div>
          <div>Lon: {selectedVessel.longitude.toFixed(4)}°</div>
        </div>
      )}
    </div>
  );
}
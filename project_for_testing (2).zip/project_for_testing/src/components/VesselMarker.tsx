import { Marker, Popup, Tooltip } from 'react-leaflet';
import { VesselData } from '../types';
import { shipIcon, washedOutShipIcon, redShipIcon } from './icons';
import { LeafletMouseEvent } from 'leaflet';
import { useMap } from 'react-leaflet';
import { useEffect, useState } from 'react';
import { createMarineTrafficUrl, createVesselUrl } from '../utils/urlUtils';

interface VesselMarkerProps {
  vessel: VesselData;
  isWashedOut: boolean;
  isRepeated: boolean;
  showLabel: boolean;
  onClick: (e: LeafletMouseEvent) => void;
}

export default function VesselMarker({ 
  vessel, 
  isWashedOut,
  isRepeated,
  showLabel,
  onClick 
}: VesselMarkerProps) {
  const map = useMap();
  const [isZoomedEnough, setIsZoomedEnough] = useState(false);

  useEffect(() => {
    const updateZoom = () => {
      setIsZoomedEnough(map.getZoom() >= 10);
    };

    updateZoom();
    map.on('zoomend', updateZoom);

    return () => {
      map.off('zoomend', updateZoom);
    };
  }, [map]);

  if (!vessel?.latitude || !vessel?.longitude) return null;

  const getIcon = () => {
    if (isWashedOut) return washedOutShipIcon;
    if (isRepeated) return redShipIcon;
    return shipIcon;
  };

  const marineTrafficUrl = createMarineTrafficUrl(vessel.mmsi);
  const vesselUrl = createVesselUrl(vessel);

  const copyVesselUrl = () => {
    navigator.clipboard.writeText(vesselUrl);
  };

  return (
    <Marker
      position={[vessel.latitude, vessel.longitude]}
      icon={getIcon()}
      eventHandlers={{
        click: onClick
      }}
      opacity={isWashedOut ? 0.4 : 1}
    >
      {isZoomedEnough && showLabel && (
        <Tooltip 
          permanent={true} 
          direction="top" 
          offset={[0, -5]}
          className={`${isWashedOut ? 'opacity-40' : ''} text-xs bg-white px-1 py-0.5 rounded shadow-sm`}
        >
          {vessel.mmsi}
        </Tooltip>
      )}
      <Popup>
        <div className="space-y-2">
          <h3 className="font-bold">Vessel Details</h3>
          <p>
            MMSI: <a 
              href={marineTrafficUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-500 hover:text-blue-700 underline"
            >
              {vessel.mmsi}
            </a>
          </p>
          <p>Speed: {vessel.speed} knots</p>
          <p>Status: {vessel.status || 'N/A'}</p>
          <p>Type: {vessel.vesselType || 'Unknown'}</p>
          <p>Turn: {vessel.turn || 'N/A'}</p>
          <p>Accuracy: {vessel.accuracy || 'N/A'}</p>
          <p>Time: {new Date(vessel.timestamp).toLocaleString()}</p>
          <button
            onClick={copyVesselUrl}
            className="mt-2 px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 text-sm"
          >
            Copy Vessel URL
          </button>
        </div>
      </Popup>
    </Marker>
  );
}

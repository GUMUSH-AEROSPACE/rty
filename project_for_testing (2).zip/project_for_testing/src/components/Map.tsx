import { useMemo, useEffect } from 'react';
import { MapContainer, TileLayer, useMapEvents, useMap } from 'react-leaflet';
import { VesselData } from '../types';
import VesselMarker from './VesselMarker';
import VesselRoute from './VesselRoute';
import ZoomLevel from './ZoomLevel';
import 'leaflet/dist/leaflet.css';

interface MapProps {
  vessels?: VesselData[];
  selectedMmsi: string | null;
  selectedVessel: VesselData | null;
  onVesselClick: (mmsi: string | null) => void;
  maxVessels?: number;
}

const defaultCenter: [number, number] = [35.1856, 33.3823];
const DEFAULT_MAX_VESSELS = 1000000;
const DEFAULT_ZOOM = 6;
const SEARCH_ZOOM = 15;

function MapClickHandler({ onMapClick }: { onMapClick: () => void }) {
  useMapEvents({
    click: onMapClick
  });
  return null;
}

function MapController({ mmsi, vessels }: { mmsi: string | null, vessels: VesselData[] }) {
  const map = useMap();

  useEffect(() => {
    if (mmsi) {
      const vessel = vessels.find(v => v.mmsi === mmsi);
      if (vessel) {
        map.setView([vessel.latitude, vessel.longitude], SEARCH_ZOOM);
      }
    }
  }, [mmsi, vessels, map]);

  return null;
}

export default function Map({ 
  vessels = [], 
  selectedMmsi, 
  selectedVessel,
  onVesselClick,
  maxVessels = DEFAULT_MAX_VESSELS 
}: MapProps) {
  const { sortedVessels, repeatedMmsi, earliestTimestamps } = useMemo(() => {
    const sorted = [...vessels]
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
      .slice(0, maxVessels);

    const mmsiCounts: Record<string, number> = {};
    const earliestTimestamps: Record<string, string> = {};

    sorted.forEach(vessel => {
      mmsiCounts[vessel.mmsi] = (mmsiCounts[vessel.mmsi] || 0) + 1;
      
      if (!earliestTimestamps[vessel.mmsi] || 
          new Date(vessel.timestamp).getTime() < new Date(earliestTimestamps[vessel.mmsi]).getTime()) {
        earliestTimestamps[vessel.mmsi] = vessel.timestamp;
      }
    });

    const repeated = new Set(
      Object.entries(mmsiCounts)
        .filter(([_, count]) => count > 1)
        .map(([mmsi]) => mmsi)
    );

    return {
      sortedVessels: sorted,
      repeatedMmsi: repeated,
      earliestTimestamps
    };
  }, [vessels, maxVessels]);

  const selectedVesselRoute = useMemo(() => {
    if (!selectedMmsi) return [];
    return sortedVessels.filter(v => v.mmsi === selectedMmsi);
  }, [sortedVessels, selectedMmsi]);

  const handleMapClick = () => {
    onVesselClick(null);
  };

  return (
    <div className="map-container">
      <MapContainer
        center={defaultCenter}
        zoom={DEFAULT_ZOOM}
        style={{ height: '100%', width: '100%' }}
        scrollWheelZoom={true}
        minZoom={2}
        maxZoom={25}
      >
        <MapClickHandler onMapClick={handleMapClick} />
        <MapController mmsi={selectedMmsi} vessels={sortedVessels} />
        <ZoomLevel selectedVessel={selectedVessel} />
        
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />

        {sortedVessels.map((vessel) => {
          // Create a truly unique key by combining MMSI and timestamp
          const uniqueKey = `${vessel.mmsi}-${vessel.timestamp}-${vessel.latitude}-${vessel.longitude}`;
          
          return (
            <VesselMarker
              key={uniqueKey}
              vessel={vessel}
              isWashedOut={selectedMmsi !== null && vessel.mmsi !== selectedMmsi}
              isRepeated={repeatedMmsi.has(vessel.mmsi)}
              showLabel={!repeatedMmsi.has(vessel.mmsi) || vessel.timestamp === earliestTimestamps[vessel.mmsi]}
              onClick={(e) => {
                e.originalEvent.stopPropagation();
                onVesselClick(vessel.mmsi);
              }}
            />
          );
        })}

        {selectedMmsi && (
          <VesselRoute 
            route={selectedVesselRoute}
          />
        )}
      </MapContainer>
    </div>
  );
}
import { useEffect } from 'react';
import { useMap } from 'react-leaflet';
import { VesselData } from '../types';
import 'leaflet-polylinedecorator'; // PolylineDecorator'ı import ediyoruz
import L from 'leaflet';

interface VesselRouteProps {
  route: VesselData[];
}

export default function VesselRoute({ route }: VesselRouteProps) {
  const map = useMap();

  if (!route || !Array.isArray(route) || route.length === 0) return null;

  const positions = route
    .filter(vessel => vessel?.latitude != null && vessel?.longitude != null)
    .map(vessel => [vessel.latitude, vessel.longitude] as [number, number]);

  if (positions.length === 0) return null;

  useEffect(() => {
    if (positions.length < 2) return;

    // Polyline oluşturma
    const polyline = L.polyline(positions, {
      color: '#0066cc',
      weight: 2,
      opacity: 0.7,
    }).addTo(map);

    // PolylineDecorator oluşturma
    const decorator = (L as any).polylineDecorator(polyline, {
      patterns: [
        {
          offset: 25,
          repeat: 50,
          symbol: (L as any).Symbol.arrowHead({
            pixelSize: 12,
            polygon: false,
            pathOptions: {
              color: '#0066cc',
              fillOpacity: 1,
              weight: 2,
            },
          }),
        },
      ],
    }).addTo(map);

    // Cleanup fonksiyonu
    return () => {
      map.removeLayer(polyline);
      map.removeLayer(decorator);
    };
  }, [map, positions]);

  return null;
}

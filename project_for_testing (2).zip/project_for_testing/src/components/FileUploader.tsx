import { ChangeEvent } from 'react';
import { FileUploaderProps, VesselData } from '../types';

interface ExtendedFileUploaderProps extends Omit<FileUploaderProps, 'onDataLoaded'> {
  onDataLoaded: (data: VesselData[], fileName: string) => void;
}

export default function FileUploader({ onDataLoaded }: ExtendedFileUploaderProps) {
  const parseCSV = (text: string): VesselData[] => {
    const lines = text.trim().split('\n');
    const headers = lines[0].split(',').map(h => h.trim());
    
    return lines.slice(1).map(line => {
      const values = line.split(',').map(v => v.trim());
      const data: Record<string, string> = {};
      
      headers.forEach((header, index) => {
        data[header] = values[index] || '';
      });

      const timestamp = new Date(data.received_time.split('.')[0]).toISOString();

      return {
        mmsi: data.mmsi,
        timestamp: timestamp,
        latitude: parseFloat(data.lat),
        longitude: parseFloat(data.lon),
        speed: parseFloat(data.speed),
        heading: 0,
        vesselType: data.msg_type,
        status: data.status,
        accuracy: parseFloat(data.accuracy),
        turn: parseFloat(data.turn)
      };
    }).filter(vessel => 
      !isNaN(vessel.latitude) && 
      !isNaN(vessel.longitude) && 
      !isNaN(vessel.speed)
    );
  };

  const handleFileUpload = (event: ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const text = e.target?.result as string;
          const data = parseCSV(text);
          onDataLoaded(data, file.name);
        } catch (error) {
          console.error('Error parsing file:', error);
          alert(`Error parsing file ${file.name}. Please ensure it's a valid CSV file.`);
        }
      };
      reader.readAsText(file);
    });

    event.target.value = '';
  };

  return (
    <div className="p-4 bg-white shadow-md rounded-lg">
      <label className="block text-sm font-medium text-gray-700">
        Upload AIS Data (CSV)
        <input
          type="file"
          accept=".csv"
          onChange={handleFileUpload}
          multiple
          className="mt-1 block w-full text-sm text-gray-500
            file:mr-4 file:py-2 file:px-4
            file:rounded-full file:border-0
            file:text-sm file:font-semibold
            file:bg-blue-50 file:text-blue-700
            hover:file:bg-blue-100"
        />
      </label>
    </div>
  );
}
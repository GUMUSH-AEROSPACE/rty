import { useState } from 'react';
import { VesselData } from '../types';

interface LoadedFilesProps {
  files: {
    name: string;
    visible: boolean;
    vessels: VesselData[];
  }[];
  onToggleVisibility: (fileName: string) => void;
  onRemoveFile: (fileName: string) => void;
}

export default function LoadedFiles({ 
  files, 
  onToggleVisibility, 
  onRemoveFile 
}: LoadedFilesProps) {
  const [isExpanded, setIsExpanded] = useState(true);

  if (files.length === 0) return null;

  return (
    <div className="border-t border-gray-200 pt-2">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-medium text-gray-700">Loaded Files</h3>
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-sm text-blue-500 hover:text-blue-700"
        >
          {isExpanded ? 'Hide' : 'Show'}
        </button>
      </div>
      
      {isExpanded && (
        <ul className="space-y-2">
          {files.map(file => (
            <li key={file.name} className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2 flex-1 min-w-0">
                <button
                  onClick={() => onToggleVisibility(file.name)}
                  className={`p-1 rounded ${file.visible ? 'text-blue-500' : 'text-gray-400'}`}
                  title={file.visible ? 'Hide vessels' : 'Show vessels'}
                >
                  {file.visible ? '👁️' : '👁️‍🗨️'}
                </button>
                <span className="truncate" title={file.name}>
                  {file.name}
                </span>
                <span className="text-gray-400 flex-shrink-0">
                  ({file.vessels.length})
                </span>
              </div>
              <button
                onClick={() => onRemoveFile(file.name)}
                className="ml-2 text-red-500 hover:text-red-700"
                title="Remove file"
              >
                ✕
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
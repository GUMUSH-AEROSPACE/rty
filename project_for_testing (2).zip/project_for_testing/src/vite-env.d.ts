/// <reference types="vite/client" />

declare module 'leaflet-polylinedecorator';

declare global {
  namespace L {
    namespace Symbol {
      function arrowHead(options: any): any;
    }
    function polylineDecorator(polyline: any, options: any): any;
  }
}
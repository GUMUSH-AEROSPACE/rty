import { useState } from 'react';
import Map from './components/Map';
import FileUploader from './components/FileUploader';
import SearchBox from './components/SearchBox';
import ErrorBoundary from './components/ErrorBoundary';
import { VesselData } from './types';
import LoadedFiles from './components/LoadedFiles';
import 'leaflet/dist/leaflet.css';

const MAX_VESSELS = 1000000;

export default function App() {
  const [vessels, setVessels] = useState<VesselData[]>([]);
  const [selectedMmsi, setSelectedMmsi] = useState<string | null>(null);
  const [loadedFiles, setLoadedFiles] = useState<{ name: string; visible: boolean; vessels: VesselData[] }[]>([]);

  const handleSearch = (mmsi: string) => {
    setSelectedMmsi(mmsi);
    const vessel = vessels.find(v => v.mmsi === mmsi);
    if (vessel) {
      const params = new URLSearchParams({
        mmsi: vessel.mmsi,
        lat: vessel.latitude.toString(),
        lon: vessel.longitude.toString(),
      });
      window.history.pushState({}, '', `?${params.toString()}`);
    }
  };

  const handleDataLoaded = (newVessels: VesselData[], fileName: string) => {
    setLoadedFiles(current => [...current, { name: fileName, visible: true, vessels: newVessels }]);
    setVessels(currentVessels => [...currentVessels, ...newVessels]);
  };

  const handleFileVisibilityToggle = (fileName: string) => {
    setLoadedFiles(current => 
      current.map(file => 
        file.name === fileName ? { ...file, visible: !file.visible } : file
      )
    );
  };

  const handleFileRemove = (fileName: string) => {
    const fileToRemove = loadedFiles.find(file => file.name === fileName);
    if (!fileToRemove) return;

    setLoadedFiles(current => current.filter(file => file.name !== fileName));
    setVessels(currentVessels => 
      currentVessels.filter(vessel => 
        !fileToRemove.vessels.some(v => 
          v.mmsi === vessel.mmsi && 
          v.timestamp === vessel.timestamp
        )
      )
    );
  };

  const visibleVessels = vessels.filter(vessel =>
    loadedFiles.some(file => 
      file.visible && 
      file.vessels.some(v => 
        v.mmsi === vessel.mmsi && 
        v.timestamp === vessel.timestamp
      )
    )
  );

  const selectedVessel = selectedMmsi 
    ? vessels.find(v => v.mmsi === selectedMmsi)
    : null;

  return (
    <div className="w-screen h-screen overflow-hidden relative">
      <ErrorBoundary>
        <Map 
          vessels={visibleVessels} 
          selectedMmsi={selectedMmsi}
          onVesselClick={setSelectedMmsi}
          maxVessels={MAX_VESSELS}
          selectedVessel={selectedVessel ?? null}  // Burada `undefined` durumu `null` ile ele alındı
        />
        <div className="absolute top-4 right-4 z-[1000] flex flex-col gap-2 w-80">
          <SearchBox onSearch={handleSearch} />
          <FileUploader onDataLoaded={handleDataLoaded} />
          {vessels.length > 0 && (
            <div className="bg-white p-4 rounded-lg shadow-md space-y-2">
              <p className="text-sm text-gray-600">
                Loaded Vessels: {vessels.length} (Visible: {visibleVessels.length})
              </p>
              <LoadedFiles 
                files={loadedFiles}
                onToggleVisibility={handleFileVisibilityToggle}
                onRemoveFile={handleFileRemove}
              />
            </div>
          )}
        </div>
      </ErrorBoundary>
    </div>
  );
}
